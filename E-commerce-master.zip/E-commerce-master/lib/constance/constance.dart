import 'package:flutter/material.dart';

const kPrimaryColor =  Color.fromRGBO(0, 197, 105, 1);